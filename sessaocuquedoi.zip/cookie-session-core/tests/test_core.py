import pytest
from cryptography.exceptions import InvalidTag

from cookie_session_core.models import ServicePolicy
from cookie_session_core.parser import parse_cookie_import, validate_cookie
from cookie_session_core.schemas import CookieImport, LaunchInput, ServiceInput
from cookie_session_core.vault import CookieVault


def test_devtools_table_and_policy():
    raw = "session\tsecret\t.example.com\t/\t2027-01-01T00:00:00Z\t20\t✓\t✓\tLax"
    cookie = parse_cookie_import(raw, "example.com")[0]
    validate_cookie(
        cookie,
        ServicePolicy(
            id="service",
            name="Example",
            upstream_url="https://example.com/",
            allowed_domains=("example.com",),
        ),
    )
    assert cookie.name == "session"
    assert cookie.same_site == "Lax"


def test_vault_is_bound_to_user_service_and_name():
    vault = CookieVault(b"x" * 32)
    encrypted = vault.encrypt("secret", "user-a", "service-a", "session")
    assert (
        vault.decrypt(encrypted.ciphertext, encrypted.nonce, "user-a", "service-a", "session")
        == "secret"
    )
    with pytest.raises(InvalidTag):
        vault.decrypt(encrypted.ciphertext, encrypted.nonce, "user-b", "service-a", "session")


def test_cookie_header():
    cookies = parse_cookie_import("session=abc; theme=dark", "example.com")
    assert [item.name for item in cookies] == ["session", "theme"]


def test_rejects_cookie_from_another_domain():
    cookie = parse_cookie_import("session=abc", "evil.example")[0]
    with pytest.raises(ValueError):
        validate_cookie(
            cookie,
            ServicePolicy(
                id="service",
                name="Example",
                upstream_url="https://example.com/",
                allowed_domains=("example.com",),
            ),
        )


def test_json_same_site_is_normalized_for_playwright():
    cookie = parse_cookie_import(
        '[{"name":"session","value":"fake","domain":"example.com","sameSite":"no_restriction"}]',
        "example.com",
    )[0]
    assert cookie.same_site == "None"


def test_service_rejects_private_destination_and_public_suffix():
    with pytest.raises(ValueError):
        ServiceInput(
            name="Private",
            upstream_url="https://127.0.0.1/",
            allowed_domains=["127.0.0.1"],
        )
    with pytest.raises(ValueError):
        ServiceInput(
            name="Suffix",
            upstream_url="https://example.co.uk/",
            allowed_domains=["co.uk"],
        )


def test_launch_and_cookie_import_do_not_accept_profiles():
    LaunchInput()
    CookieImport(cookies="session=fake")
    with pytest.raises(ValueError):
        LaunchInput(profile_id="00000000-0000-0000-0000-000000000001")
    with pytest.raises(ValueError):
        CookieImport(cookies="session=fake", label="Old profile")
