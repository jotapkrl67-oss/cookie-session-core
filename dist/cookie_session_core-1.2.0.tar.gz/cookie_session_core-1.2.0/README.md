# Cookie Session Core

Reverse proxy headless para ser conectado a um projeto **Lovable/Supabase existente**.
O Lovable continua responsável por login, usuários, permissões, layout e navegação.
Este container mantém os cookies originais no servidor e entrega ao navegador
somente um grant opaco, `HttpOnly`, do próprio proxy.

## O que está pronto

- API FastAPI autenticada com JWT do Supabase;
- compatibilidade com JWT assimétrico via JWKS e projetos legados HS256;
- autorização administrativa intermediada pela Edge Function do projeto existente;
- importação DevTools, JSON, Netscape e Cookie header;
- AES-256-GCM com chave derivada por usuário e serviço;
- token de lançamento com 30 segundos e consumo único;
- reverse proxy HTTP com cookies injetados exclusivamente no upstream;
- captura de `Set-Cookie` no cofre, expondo ao JavaScript somente cookies que
  originalmente não eram `HttpOnly`, sob nomes internos isolados;
- reescrita de redirects, HTML/CSS/JS/JSON, CSP e WebSockets;
- recuperação genérica de navegações, APIs, workers e assets que escapam de
  `/proxy/:serviceId`, com redirect canônico para documentos;
- emulação de cookies com escopo real de domínio/caminho, nomes duplicados,
  expiração, exclusão e Cookie Store API, sem misturar hosts irmãos;
- isolamento por serviço de cookies visíveis ao JavaScript, `localStorage`,
  `sessionStorage`, IndexedDB, WebSQL, Web Locks, CacheStorage e BroadcastChannel;
- reescrita de manifests, `@import`, CSSOM, worklets, atributos lazy/srcset,
  meta refresh, service workers e APIs DOM criadas dinamicamente;
- semântica de credenciais de `fetch`, XHR e EventSource preservada entre hosts
  lógicos, com o header interno removido antes do upstream;
- allowlist estrita: apenas domínios cadastrados e seus subdomínios são
  roteados; o core não infere hosts irmãos pelo domínio registrável;
- suporte a widgets legítimos de Cloudflare Turnstile, reCAPTCHA, hCaptcha e
  desafios que carregam recursos dinamicamente;
- diagnóstico seguro de Cloudflare Challenge Pages quando a topologia é
  incompatível;
- sincronização de cookies rotacionados no PostgreSQL;
- renovação automática de cookies Cloudflare por um microserviço Playwright
  isolado, com User-Agent vinculado e single-flight;
- auditoria sem valores sensíveis;
- diagnóstico persistente de autenticação, proxy, upstream e JavaScript do navegador;
- Dockerfile e configuração Railway;
- migration PostgreSQL/Supabase com tabelas prefixadas;
- inicialização idempotente das tabelas em PostgreSQL próprio do Railway;
- Edge Function e cliente TypeScript de integração.

## Arquitetura

```text
Projeto Lovable existente
  ├── componentes e rotas atuais
  ├── Supabase Auth atual
  └── cookieCoreClient.ts
          │
          ▼
Supabase Edge Function cookie-core
  ├── valida JWT
  ├── usa a regra de administrador já existente
  └── adiciona segredo interno somente em operações administrativas
          │
          ▼
Container Railway
  ├── FastAPI
  ├── Cookie Session Core
  ├── reverse proxy HTTP/WebSocket
  └── cofre AES-256-GCM
          │
          ▼
PostgreSQL do Supabase ou Railway
```

Quando o banco for o PostgreSQL do próprio Railway, configure
`DATABASE_URL=${{Postgres.DATABASE_URL}}`. As tabelas prefixadas são criadas
automaticamente na inicialização; o Lovable Cloud continua responsável pela
autenticação e pela integração server-side.

## Estrutura

```text
Dockerfile
railway.toml
sql/schema.sql
src/cookie_session_core/
  app.py
  auth.py
  config.py
  core.py
  parser.py
  reverse_proxy.py
  schemas.py
  vault.py
lovable-integration/
  cookieCoreClient.ts
  supabase/functions/cookie-core/index.ts
INSTRUCOES_CONTAINER_RAILWAY.md
PROMPT_LOVABLE.md
```

## Rotas

```text
GET    /health/live
GET    /health/ready
GET    /metrics
GET    /v1/services
POST   /v1/services/:serviceId/launch
GET    /v1/admin/services
POST   /v1/admin/services
PUT    /v1/admin/services/:serviceId
GET    /v1/admin/services/:serviceId/users/:userId/cookies
POST   /v1/admin/services/:serviceId/users/:userId/cookies/import
DELETE /v1/admin/services/:serviceId/users/:userId/cookies
GET    /v1/admin/services/:serviceId/users/:userId/localstorage
POST   /v1/admin/services/:serviceId/users/:userId/localstorage/import
DELETE /v1/admin/services/:serviceId/users/:userId/localstorage
GET    /v1/admin/cf/status
POST   /v1/admin/cf/solve
GET    /v1/admin/cf/clearance
POST   /v1/admin/cf/clearance
DELETE /v1/admin/cf/clearance/:domain
```

A importação de `localStorage` recebe `{ "items": "{\"chave\":\"valor\"}" }`.
Ela substitui somente o conjunto de `localStorage`, sem alterar cookies. Os
valores permanecem criptografados no banco, são carregados antes dos scripts da
ferramenta e alterações feitas pela aplicação são sincronizadas de volta. A API
administrativa lista apenas chaves e datas, nunca valores.

`/metrics` expõe counters Prometheus em memória e pode ser desabilitado com
`METRICS_ENABLED=false`. Para fallback de solver em cascata, configure
`CF_SOLVER_PROVIDERS=yescaptcha,custom,capsolver`; chaves distintas podem ser
fornecidas como JSON em `CF_SOLVER_API_KEYS` e timeouts por provider em
`CF_SOLVER_PROVIDER_TIMEOUTS`. `CF_SOLVER_PROVIDER` e `CF_SOLVER_API_KEY`
continuam compatíveis para instalações com um único provider.

## Log de diagnóstico persistente

O core grava eventos estruturados em texto, com timestamp UTC e `request_id`, em
`LOG_FILE_PATH` (padrão: `/app/logs/cookie-session-core.txt`). O arquivo registra
falhas de autenticação/autorização, respostas HTTP 4xx/5xx, exceções com traceback,
upstreams indisponíveis, requisições lentas e erros JavaScript não tratados nas
páginas proxied. Authorization, Cookie, tokens, senhas, chaves, credenciais em URLs
e query strings são mascarados antes da gravação; bodies de login/importação não
são coletados.

Configuração disponível:

```env
LOG_FILE_PATH=/data/logs/cookie-session-core.txt
LOG_LEVEL=INFO
LOG_MAX_BYTES=20000000
LOG_BACKUP_COUNT=5
LOG_SLOW_REQUEST_MS=3000
```

Use um volume persistente da VPS montado em `/data` (ou outro diretório gravável)
para o histórico sobreviver à recriação do container. A rotação mantém o arquivo
atual mais `LOG_BACKUP_COUNT` cópias e impede crescimento ilimitado. Se o caminho
não puder ser criado, o core continua ativo e envia os diagnósticos ao stderr.
Em bind mounts, dê ao UID `10001` do container permissão de escrita no diretório
de logs antes de subir o serviço.

Para acompanhar ao vivo na VPS:

```bash
tail -F /data/logs/cookie-session-core.txt
```

Por padrão, o `launch_url` aponta para `/proxy/:serviceId/*`. Quando o serviço tem
`proxy_hostname`, ele aponta para `https://<proxy_hostname>/*`, preservando os
caminhos originais como um proxy transparente. O Lovable apenas abre a URL em
outra aba. O token é consumido uma vez, removido por redirect `303` e trocado por
`__Secure-cookie_core_proxy`.

O grant do proxy usa expiração deslizante por inatividade. Requisições normais,
downloads/SSE longos e WebSockets ativos renovam o registro no banco; o cookie do
navegador é de sessão e não prolonga um grant revogado ou já expirado. Ajuste
`PROXY_GRANT_TTL_SECONDS` e `PROXY_GRANT_REFRESH_INTERVAL_SECONDS` se necessário.
O bloqueio visual de seletores conhecidos de troca de conta é ativo por padrão;
se um produto legítimo gerar falso positivo, use `PROFILE_LOCK_ENABLED=false`.

Ao atualizar uma instalação antiga com múltiplos perfis, a inicialização preserva
para cada usuário e serviço somente os cookies do perfil padrão — ou do mais
recentemente atualizado — e remove a estrutura de perfis. Grants e lançamentos
temporários anteriores ao deploy são invalidados.

## Implantação

Siga [INSTRUCOES_CONTAINER_RAILWAY.md](INSTRUCOES_CONTAINER_RAILWAY.md).

## Regras invariantes

- Cookies `HttpOnly` nunca chegam ao JavaScript. Cookies que eram visíveis ao
  JavaScript no site original continuam visíveis por uma camada interna isolada,
  pois aplicações dependem deles para CSRF e estado de interface.
- O administrador importa por uma Edge Function do sistema existente.
- O usuário comum nunca recebe a opção de importar.
- Toda ferramenta habilitada aparece para todos os usuários autenticados.
- Existe somente um conjunto de cookies por `user_id + service_id`; não há perfis.
- O cookie interno do proxy nunca contém `user_id` ou cookies do site.
- Todo grant e todo cookie são novamente vinculados a `user_id + service_id`
  no banco antes de uma requisição upstream.
- Não registre headers Authorization/Cookie, bodies de importação ou launch tokens.

## Limites da reescrita

HTML, CSS, manifests e URLs absolutas em JavaScript/JSON são reescritos. O
adaptador cobre `fetch`, XHR, `sendBeacon`, EventSource, WebSocket, workers,
History/Navigation API, propriedades e atributos DOM, CSSOM, Cookie Store e os
principais storages do navegador. Respostas autenticadas HTML/JSON/SSE são
marcadas `private, no-store` para impedir estado de login obsoleto ou cache entre
usuários. Aplicações que constroem URLs por ofuscação, usam pinagem de origem,
assinatura de URL, DRM ou service workers podem exigir um adaptador específico.
Cadastre explicitamente todos os hosts legítimos usados pelo serviço em
`allowed_domains`; cadastrar `app.exemplo.com` não libera `auth.exemplo.com`.

Para máxima compatibilidade, use um `proxy_hostname` dedicado para cada serviço.
O modo `/proxy/:serviceId` possui isolamento e fallback de rotas, mas continua
compartilhando a origem pública da API; aplicações que comparam rigidamente
`location.origin` funcionam melhor em um hostname dedicado.

Nenhum reverse proxy pode prometer compatibilidade literal com todos os sites.
Continuam dependendo de configuração externa ou da origem real:

- Google OAuth/GSI e SDKs equivalentes exigem que o hostname público esteja nos
  *Authorized JavaScript origins* do cliente OAuth;
- DRM, WebAuthn/passkeys, pinagem de origem, certificados de cliente e URLs
  assinadas vinculadas ao hostname podem recusar uma origem intermediária;
- Cloudflare Managed Challenge não pode emitir clearance válido para um vanity
  hostname diferente do hostname protegido;
- service workers ou bundles ofuscados que removem `Referer` podem exigir um
  adaptador específico do produto.

Avisos de preload não utilizado e telemetria RUM não impedem a aplicação. O
endpoint opcional `/cdn-cgi/rum` é reconhecido localmente para não produzir 404.
Scripts como `passwordCapture.js` não fazem parte deste projeto; se aparecerem no
console, revise extensões e scripts injetados no navegador.

## Provider Playwright para Cloudflare

Para usar o microserviço separado, configure `PLAYWRIGHT_SERVICE_URL`,
`PLAYWRIGHT_SERVICE_TOKEN` e `CF_AUTO_REFRESH=true`. A arquitetura, implantação
no Railway, testes, renovação e limitações de fingerprint estão documentados em
[docs/cloudflare-provider.md](docs/cloudflare-provider.md).

Cookies protegidos por mecanismos anti-bot podem depender do IP e navegador que os
criou.

Quando o provider Playwright estiver em outra infraestrutura, configure o mesmo
forward proxy de saída nos dois serviços para reduzir incompatibilidade de IP:

```env
# Cookie Session Core
UPSTREAM_PROXY_URL=http://proxy-vps.example.com:3128
UPSTREAM_PROXY_USERNAME=usuario
UPSTREAM_PROXY_PASSWORD=senha

# Playwright Service
BROWSER_PROXY_SERVER=http://proxy-vps.example.com:3128
BROWSER_PROXY_USERNAME=usuario
BROWSER_PROXY_PASSWORD=senha
```

O core aplica `UPSTREAM_PROXY_*` ao HTTP e ao WebSocket. Sem essa configuração,
core e Playwright podem sair por IPs diferentes e um `cf_clearance` vinculado ao
IP pode ser recusado.

### Cloudflare Managed Challenge

O proxy detecta a resposta oficial `cf-mitigated: challenge` e guarda qualquer
`Set-Cookie` somente no cofre. Uma Challenge Page só pode ser retransmitida quando
o endereço público tem exatamente a mesma origem HTTPS do upstream. Preservar os
caminhos em um `proxy_hostname` dedicado não basta: `chat.exemplo.com` continua
sendo uma origem diferente de `chatgpt.com`, e os tokens/cookies do desafio não
podem ser validados nesse outro domínio.

Quando a origem não coincide — tanto no modo `/proxy/:serviceId` quanto no modo
transparente — a resposta é `502`, com `X-Cookie-Core-Upstream-Challenge` e
`X-Cookie-Core-Cf-Ray`, em vez de deixar o navegador preso em uma verificação que
não pode terminar.

Se o serviço usa `allowed_cookie_names`, inclua também os cookies exigidos pela
proteção (por exemplo, `cf_clearance` e `__cf_bm`). Com a lista vazia, cookies
válidos dos domínios permitidos são capturados normalmente.

Para um upstream sob seu controle, a solução é feita no Cloudflare WAF/Access:

- use um IP de saída estático para o container e crie uma regra WAF restrita que
  não aplique Challenge a esse IP; ou
- proteja a comunicação proxy/upstream com Cloudflare Access e credenciais de
  serviço (máquina-a-máquina); ou
- use Turnstile com pre-clearance no hostname real quando o navegador acessa esse
  mesmo hostname diretamente.

Widgets Turnstile embutidos e equivalentes continuam funcionando em domínio
separado: a CSP permite HTTPS para scripts, imagens, frames, conexões e workers, e
o adaptador cobre `fetch`, XHR, `sendBeacon`, EventSource, WebSocket, Worker,
SharedWorker, atributos DOM dinâmicos e navegação por History API. O hostname do
proxy ainda precisa estar autorizado na configuração do próprio widget. Cookies
criados pelo JavaScript da página são isolados por serviço no navegador e só são
enviados ao upstream correspondente; cookies recebidos do upstream continuam
exclusivamente no cofre.
