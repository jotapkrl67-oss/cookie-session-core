from __future__ import annotations

import asyncio
import socket

import pytest
from fastapi import HTTPException, Request
from playwright_service.app import (
    Settings,
    SolveCapacity,
    _transport_cookies,
    _validate_public_url,
    sanitized_http_error,
)


@pytest.mark.asyncio
async def test_dns_answer_mixing_public_and_private_is_rejected(monkeypatch):
    def mixed(*args, **kwargs):
        return [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("1.1.1.1", 443)),
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.1", 443)),
        ]

    monkeypatch.setattr(socket, "getaddrinfo", mixed)
    with pytest.raises(HTTPException, match="Private destinations"):
        await _validate_public_url(
            "https://mixed.example/", Settings(playwright_service_token="t" * 32)
        )


@pytest.mark.asyncio
async def test_disallowed_port_and_cgnat_are_rejected():
    settings = Settings(playwright_service_token="t" * 32)
    with pytest.raises(HTTPException, match="port is not allowed"):
        await _validate_public_url("https://1.1.1.1:8443/", settings)
    with pytest.raises(HTTPException, match="Private destinations"):
        await _validate_public_url("http://100.64.0.1/", settings)


def test_proxy_credentials_embedded_in_url_are_rejected():
    with pytest.raises(ValueError, match="without credentials"):
        Settings(
            playwright_service_token="t" * 32,
            browser_proxy_server="http://user:password@proxy.example:3128",
        )


@pytest.mark.asyncio
async def test_capacity_rejects_when_queue_is_full():
    capacity = SolveCapacity(1, 0)
    entered = asyncio.Event()
    release = asyncio.Event()

    async def hold():
        async with capacity.acquire(1):
            entered.set()
            await release.wait()

    task = asyncio.create_task(hold())
    await entered.wait()
    with pytest.raises(HTTPException) as exc:
        async with capacity.acquire(1):
            pass
    assert exc.value.status_code == 429
    release.set()
    await task
    assert capacity.active == capacity.queued == 0


def test_transport_contract_drops_partitioned_and_unknown_cookie_fields():
    settings = Settings(playwright_service_token="t" * 32)
    cookies = [
        {
            "name": "partitioned",
            "value": "not-replayable",
            "domain": ".example.com",
            "path": "/",
            "expires": 1_900_000_000,
            "httpOnly": True,
            "secure": True,
            "sameSite": "None",
            "partitionKey": "https://top-level.example",
        },
        {
            "name": "cf_clearance",
            "value": "clearance",
            "domain": ".example.com",
            "path": "/",
            "expires": 1_900_000_000,
            "httpOnly": True,
            "secure": True,
            "sameSite": "None",
            "unexpectedBrowserField": "must-not-cross-contract",
        },
    ]

    result = _transport_cookies(cookies, settings)

    assert len(result) == 1
    assert result[0]["name"] == "cf_clearance"
    assert "partitionKey" not in result[0]
    assert "unexpectedBrowserField" not in result[0]


def test_partitioned_clearance_is_a_permanent_contract_error():
    settings = Settings(playwright_service_token="t" * 32)
    with pytest.raises(HTTPException) as exc:
        _transport_cookies(
            [
                {
                    "name": "cf_clearance",
                    "value": "partition-bound",
                    "domain": ".example.com",
                    "path": "/",
                    "partitionKey": "https://example.com",
                }
            ],
            settings,
        )
    assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_solve_error_response_is_sanitized(caplog):
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/solve",
        "headers": [],
        "query_string": b"",
        "server": ("test", 443),
        "client": ("127.0.0.1", 1),
        "scheme": "https",
    }
    request = Request(scope)
    with caplog.at_level("WARNING", logger="uvicorn.error"):
        response = await sanitized_http_error(
            request, HTTPException(502, "Browser operation failed")
        )
    assert response.status_code == 502
    assert b'"detail":"Browser operation failed"' in response.body
    assert "Browser operation failed" in caplog.text


@pytest.mark.asyncio
async def test_solve_error_replaces_log_forging_request_id():
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/solve",
        "headers": [(b"x-request-id", b"bad id with spaces")],
        "query_string": b"",
        "server": ("test", 443),
        "client": ("127.0.0.1", 1),
        "scheme": "https",
    }
    response = await sanitized_http_error(
        Request(scope), HTTPException(502, "Browser operation failed")
    )

    request_id = response.headers["x-request-id"]
    assert len(request_id) == 32
    assert request_id != "bad id with spaces"
