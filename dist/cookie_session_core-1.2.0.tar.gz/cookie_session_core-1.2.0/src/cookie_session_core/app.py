from __future__ import annotations

import asyncio
import hashlib
import logging
import math
import re
import secrets
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager, suppress
from importlib.resources import files
from typing import Any
from urllib.parse import urlencode, urlparse
from uuid import UUID

import asyncpg
from fastapi import Depends, FastAPI, HTTPException, Request, Response, WebSocket
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse

from .auth import AuthenticatedUser, SupabaseJWTVerifier, current_admin, current_user
from .browser_client import BrowserLikeClient
from .cloudflare_provider import HttpCloudflareCookieProvider
from .config import get_settings
from .core import CookieSessionCore
from .diagnostic_logging import configure_diagnostic_logging
from .egress import PublicAddressGuard
from .redaction import install_redaction
from .reverse_proxy import (
    LAUNCH_QUERY_PARAM,
    LEGACY_LAUNCH_QUERY_PARAM,
    ReverseProxy,
    escaped_proxy_service_id,
    proxy_hostname_candidates,
)
from .schemas import (
    CfClearanceInject,
    CfSolveUrlInput,
    CookieImport,
    LaunchInput,
    LocalStorageImport,
    ServiceInput,
)

logger = logging.getLogger("cookie_session_core")
install_redaction(logger)
APP_VERSION = "1.2.0"
_SAFE_REQUEST_ID = re.compile(r"^[A-Za-z0-9_.-]{1,80}$")


async def _transparent_service(proxy: ReverseProxy, headers, fallback: str | None):
    for hostname in proxy_hostname_candidates(headers, fallback):
        service_id = await proxy.service_id_for_hostname(hostname)
        if service_id:
            return service_id, hostname
    return None, None


class RateLimiter:
    def __init__(self):
        self.events: dict[tuple[str, str], deque[float]] = defaultdict(deque)
        self.last_sweep = 0.0

    def check(self, scope: str, subject: str, maximum: int, window: int = 60) -> None:
        now = time.monotonic()
        if now - self.last_sweep >= 60:
            for key, existing in list(self.events.items()):
                while existing and existing[0] <= now - window:
                    existing.popleft()
                if not existing:
                    self.events.pop(key, None)
            self.last_sweep = now
        bucket = self.events[(scope, subject)]
        while bucket and bucket[0] <= now - window:
            bucket.popleft()
        if len(bucket) >= maximum:
            retry_after = max(1, math.ceil(bucket[0] + window - now))
            raise HTTPException(
                429,
                "Too many requests; try again shortly",
                headers={"Retry-After": str(retry_after)},
            )
        bucket.append(now)


async def _cleanup_tokens(pool: asyncpg.Pool) -> None:
    while True:
        await asyncio.sleep(60)
        try:
            await pool.execute("DELETE FROM cookie_core_launch_tokens WHERE expires_at < now()")
            await pool.execute("DELETE FROM cookie_core_proxy_grants WHERE expires_at < now()")
        except Exception as exc:
            logger.warning("token_cleanup_failed error=%s", type(exc).__name__)


async def _initialize_database(settings) -> asyncpg.Pool:
    last_error: Exception | None = None
    for attempt in range(1, settings.database_startup_attempts + 1):
        pool: asyncpg.Pool | None = None
        try:
            pool = await asyncpg.create_pool(
                settings.database_url,
                min_size=1,
                max_size=20,
                command_timeout=30,
            )
            await pool.fetchval("SELECT 1")
            schema = files("cookie_session_core").joinpath("schema.sql").read_text(
                encoding="utf-8"
            )
            await pool.execute(schema)
            return pool
        except Exception as exc:
            last_error = exc
            if pool is not None:
                with suppress(Exception):
                    await pool.close()
            if attempt >= settings.database_startup_attempts:
                break
            delay = min(0.5 * (2 ** (attempt - 1)), settings.database_startup_max_delay_seconds)
            logger.warning(
                "database_startup_retry attempt=%s/%s delay_seconds=%.1f error=%s",
                attempt,
                settings.database_startup_attempts,
                delay,
                type(exc).__name__,
            )
            await asyncio.sleep(delay)
    assert last_error is not None
    raise last_error


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    pool = await _initialize_database(settings)
    core = CookieSessionCore(
        pool,
        settings.vault_key,
        settings.token_pepper,
        set(settings.blocked_cookie_public_suffixes),
    )
    cookie_provider = None
    if settings.cloudflare_cookie_provider_enabled:
        cookie_provider = HttpCloudflareCookieProvider(
            str(settings.playwright_service_url),
            settings.playwright_service_token,
            timeout=float(settings.cf_solver_timeout_seconds),
            max_retries=settings.cf_solver_max_retries,
            allow_insecure_http=settings.playwright_service_allow_insecure_http,
        )
    browser_client = BrowserLikeClient(
        impersonate="chrome124",
        timeout=float(settings.proxy_timeout_seconds),
        max_connections=100,
        settings=settings,
        cloudflare_cookie_provider=cookie_provider,
    )
    cleanup_task = asyncio.create_task(_cleanup_tokens(pool))
    app.state.settings = settings
    app.state.pool = pool
    app.state.core = core
    app.state.proxy = ReverseProxy(core, settings, browser_client)
    app.state.browser_client = browser_client
    app.state.jwt_verifier = SupabaseJWTVerifier(settings)
    app.state.rate_limiter = RateLimiter()
    app.state.egress_guard = PublicAddressGuard(cache_seconds=settings.egress_dns_cache_seconds)
    try:
        yield
    finally:
        cleanup_task.cancel()
        with suppress(asyncio.CancelledError):
            await cleanup_task
        try:
            await browser_client.aclose()
        finally:
            await pool.close()


def create_app() -> FastAPI:
    resolved = get_settings()
    configure_diagnostic_logging(
        file_path=resolved.log_file_path,
        level=resolved.log_level,
        max_bytes=resolved.log_max_bytes,
        backup_count=resolved.log_backup_count,
    )
    app = FastAPI(
        title="Cookie Session Core",
        version=APP_VERSION,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=resolved.origin_list,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=[
            "Authorization",
            "Content-Type",
            "X-Cookie-Core-Admin",
            "X-Force-OAI-Rotate",
        ],
    )

    @app.exception_handler(RequestValidationError)
    async def sanitized_validation_error(request: Request, exc: RequestValidationError):
        errors = [
            {
                "field": ".".join(str(part) for part in item.get("loc", ()) if part != "body"),
                "message": item.get("msg", "Invalid value"),
            }
            for item in exc.errors()
        ]
        logger.warning(
            "request_validation_failed request_id=%s method=%s path=%s fields=%s",
            getattr(request.state, "request_id", "unknown"),
            request.method,
            request.url.path,
            ",".join(item["field"] for item in errors) or "unknown",
        )
        return JSONResponse(
            {"detail": "Invalid request", "errors": errors},
            status_code=422,
        )

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        supplied_request_id = request.headers.get("x-request-id", "")
        request_id = (
            supplied_request_id
            if _SAFE_REQUEST_ID.fullmatch(supplied_request_id)
            else secrets.token_hex(12)
        )
        request.state.request_id = request_id
        started_at = time.monotonic()
        try:
            public_hosts = proxy_hostname_candidates(request.headers, request.url.hostname)
            escaped_service_id = escaped_proxy_service_id(
                request.url.path,
                request.headers.get("referer"),
                request.cookies,
                public_hosts[0] if public_hosts else request.url.hostname,
            )
            if (
                request.url.path.startswith("/proxy/")
                or request.cookies.get("__Secure-cookie_core_proxy")
                or escaped_service_id
                or request.query_params.get(LAUNCH_QUERY_PARAM)
                or request.query_params.get(LEGACY_LAUNCH_QUERY_PARAM)
            ):
                raw_grant = request.cookies.get(
                    "__Secure-cookie_core_proxy"
                ) or request.query_params.get(LAUNCH_QUERY_PARAM)
                if not raw_grant:
                    raw_grant = request.query_params.get(LEGACY_LAUNCH_QUERY_PARAM)
                if not raw_grant and escaped_service_id:
                    raw_grant = request.cookies.get(
                        f"__Secure-cookie_core_proxy_{escaped_service_id}"
                    )
                if not raw_grant:
                    raw_grant = request.client.host if request.client else "unknown"
                launch_subject = hashlib.sha256(raw_grant.encode()).hexdigest()
                request.app.state.rate_limiter.check("proxy", launch_subject, 1800)
            service_id, hostname = (None, None)
            if not escaped_service_id:
                service_id, hostname = await _transparent_service(
                    request.app.state.proxy,
                    request.headers,
                    request.url.hostname,
                )
            if escaped_service_id:
                request.state.cookie_core_proxy = True
                if (
                    request.headers.get("sec-fetch-mode", "").lower() == "navigate"
                    or request.headers.get("sec-fetch-dest", "").lower() == "document"
                ):
                    query = request.scope.get("query_string", b"").decode("latin-1")
                    destination = f"/proxy/{escaped_service_id}{request.url.path}"
                    if query:
                        destination += "?" + query
                    response = RedirectResponse(destination, status_code=307)
                else:
                    response = await request.app.state.proxy.http(
                        escaped_service_id,
                        request.url.path.lstrip("/"),
                        request,
                    )
            elif service_id:
                request.state.cookie_core_proxy = True
                response = await request.app.state.proxy.http(
                    service_id,
                    request.url.path.lstrip("/"),
                    request,
                    transparent=True,
                    transparent_hostname=hostname,
                )
            else:
                response = await call_next(request)
        except HTTPException as exc:
            logger.warning(
                "request_rejected request_id=%s method=%s host=%s path=%s status=%s reason=%s",
                request_id,
                request.method,
                request.headers.get("x-forwarded-host") or request.url.hostname,
                request.url.path,
                exc.status_code,
                exc.detail,
            )
            response = JSONResponse(
                {"detail": exc.detail},
                status_code=exc.status_code,
                headers=exc.headers,
            )
        except Exception as exc:
            logger.exception(
                "request_failed request_id=%s method=%s host=%s path=%s error=%s",
                request_id,
                request.method,
                request.headers.get("x-forwarded-host") or request.url.hostname,
                request.url.path,
                type(exc).__name__,
            )
            response = JSONResponse(
                {"detail": "Internal service error", "request_id": request_id},
                status_code=500,
            )
        request.app.state.proxy.finalize_browser_response(request, response)
        duration_ms = round((time.monotonic() - started_at) * 1000)
        if response.status_code >= 400:
            level = logging.ERROR if response.status_code >= 500 else logging.WARNING
            logger.log(
                level,
                "request_completed_with_error request_id=%s method=%s host=%s path=%s status=%s duration_ms=%s source=%s",
                request_id,
                request.method,
                request.headers.get("x-forwarded-host") or request.url.hostname,
                request.url.path,
                response.status_code,
                duration_ms,
                response.headers.get("x-cookie-core-error-source", "application"),
            )
        elif duration_ms >= request.app.state.settings.log_slow_request_ms:
            logger.warning(
                "slow_request request_id=%s method=%s host=%s path=%s status=%s duration_ms=%s",
                request_id,
                request.method,
                request.headers.get("x-forwarded-host") or request.url.hostname,
                request.url.path,
                response.status_code,
                duration_ms,
            )
        response.headers["X-Request-ID"] = request_id
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        if request.url.path.startswith("/proxy/") or getattr(
            request.state, "cookie_core_proxy", False
        ):
            response.headers["Referrer-Policy"] = "same-origin"
        else:
            response.headers["Referrer-Policy"] = "no-referrer"
            response.headers["Permissions-Policy"] = "camera=(), geolocation=(), payment=()"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["Content-Security-Policy"] = (
                "default-src 'none'; script-src 'self'; style-src 'self'; "
                "img-src 'self' blob: data:; connect-src 'self' wss:; "
                "frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
            )
        return response

    @app.get("/health/live")
    async def health():
        return {
            "status": "ok",
            "version": APP_VERSION,
            "proxy": True,
        }

    @app.get("/health/ready")
    async def readiness(request: Request):
        try:
            database_ready = bool(
                await asyncio.wait_for(request.app.state.pool.fetchval("SELECT 1"), timeout=3)
            )
        except Exception as exc:
            logger.warning("readiness_failed dependency=database error=%s", type(exc).__name__)
            raise HTTPException(503, "Database is not ready") from exc
        return {
            "status": "ready",
            "version": APP_VERSION,
            "database": database_ready,
            "proxy": True,
        }

    @app.get("/metrics", include_in_schema=False)
    async def prometheus_metrics(request: Request):
        if not request.app.state.settings.metrics_enabled:
            raise HTTPException(404, "Not found")
        from .metrics import metrics

        return Response(metrics.render(), media_type="text/plain; version=0.0.4")

    @app.get("/v1/services")
    async def list_user_services(request: Request, user: AuthenticatedUser = Depends(current_user)):
        request.app.state.rate_limiter.check("services", user.id, 10)
        rows = await request.app.state.pool.fetch(
            """SELECT s.id,s.name,s.category,s.enabled,
                      (SELECT count(*) FROM cookie_core_stored_cookies c
                       WHERE c.service_id=s.id AND c.user_id=$1
                         AND c.revoked_at IS NULL
                         AND (c.expires_at IS NULL OR c.expires_at > now())) AS active_cookies,
                      (SELECT count(*) FROM cookie_core_stored_localstorage l
                       WHERE l.service_id=s.id AND l.user_id=$1
                         AND l.revoked_at IS NULL) AS active_localstorage
               FROM cookie_core_services s
               WHERE s.enabled=true
               ORDER BY s.name""",
            user.id,
        )
        return {
            "services": [
                {
                    "id": str(row["id"]),
                    "name": row["name"],
                    "category": row["category"],
                    "enabled": row["enabled"],
                    "status": "ready"
                    if (row["active_cookies"] or row["active_localstorage"])
                    else "not_configured",
                    "active_cookies": row["active_cookies"],
                    "active_localstorage": row["active_localstorage"],
                }
                for row in rows
            ]
        }

    @app.post("/v1/services/{service_id}/launch")
    async def launch_service(
        service_id: UUID,
        request: Request,
        _data: LaunchInput | None = None,
        user: AuthenticatedUser = Depends(current_user),
    ):
        request.app.state.rate_limiter.check("launch", user.id, 5)
        try:
            token = await request.app.state.core.issue_launch(
                user_id=user.id,
                service_id=str(service_id),
                ttl_seconds=30,
            )
        except ValueError as exc:
            raise HTTPException(404, str(exc))
        service = await request.app.state.pool.fetchrow(
            """SELECT upstream_url,proxy_hostname FROM cookie_core_services
               WHERE id=$1 AND enabled=true""",
            service_id,
        )
        # The service can be disabled/deleted between issue_launch and this
        # lookup. Handle that race as an ordinary 404 instead of a server error.
        if not service:
            raise HTTPException(404, "Service not found or disabled")
        upstream = urlparse(service["upstream_url"])
        upstream_path = upstream.path or "/"
        base = (
            f"https://{service['proxy_hostname']}"
            if service["proxy_hostname"]
            else str(request.app.state.settings.public_base_url).rstrip("/")
            + f"/proxy/{service_id}"
        )
        query = upstream.query
        query += ("&" if query else "") + urlencode({LAUNCH_QUERY_PARAM: token})
        return {
            "launch_url": f"{base}{upstream_path}?{query}",
            "expires_in": 30,
        }

    @app.get("/v1/admin/services")
    async def admin_services(request: Request, _: AuthenticatedUser = Depends(current_admin)):
        rows = await request.app.state.pool.fetch(
            "SELECT * FROM cookie_core_services ORDER BY name"
        )
        return {
            "services": [
                {
                    "id": str(row["id"]),
                    "name": row["name"],
                    "category": row["category"],
                    "upstream_url": row["upstream_url"],
                    "proxy_hostname": row["proxy_hostname"],
                    "allowed_domains": row["allowed_domains"],
                    "allowed_paths": row["allowed_paths"],
                    "allowed_cookie_names": row["allowed_cookie_names"],
                    "enabled": row["enabled"],
                }
                for row in rows
            ]
        }

    @app.post("/v1/admin/services", status_code=201)
    async def create_service(
        data: ServiceInput,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        request.app.state.rate_limiter.check("admin-write", admin.id, 20)
        try:
            await request.app.state.egress_guard.check(str(data.upstream_url))
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        row = await request.app.state.pool.fetchrow(
            """INSERT INTO cookie_core_services(
                 name,category,upstream_url,proxy_hostname,allowed_domains,allowed_paths,
                 allowed_cookie_names,enabled
               ) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *""",
            data.name,
            data.category,
            str(data.upstream_url),
            data.proxy_hostname,
            data.allowed_domains,
            data.allowed_paths,
            data.allowed_cookie_names,
            data.enabled,
        )
        await request.app.state.pool.execute(
            """INSERT INTO cookie_core_audit_logs(
                 actor_user_id,subject_user_id,service_id,action,details
               ) VALUES($1,$1,$2,'service.create','{}'::jsonb)""",
            admin.id,
            row["id"],
        )
        request.app.state.proxy.clear_hostname_cache()
        return {"id": str(row["id"]), "name": row["name"]}

    @app.put("/v1/admin/services/{service_id}")
    async def update_service(
        service_id: UUID,
        data: ServiceInput,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        request.app.state.rate_limiter.check("admin-write", admin.id, 20)
        try:
            await request.app.state.egress_guard.check(str(data.upstream_url))
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        row = await request.app.state.pool.fetchrow(
            """UPDATE cookie_core_services SET
                 name=$1,category=$2,upstream_url=$3,proxy_hostname=$4,allowed_domains=$5,
                 allowed_paths=$6,allowed_cookie_names=$7,enabled=$8,updated_at=now()
               WHERE id=$9 RETURNING id,name""",
            data.name,
            data.category,
            str(data.upstream_url),
            data.proxy_hostname,
            data.allowed_domains,
            data.allowed_paths,
            data.allowed_cookie_names,
            data.enabled,
            service_id,
        )
        if not row:
            raise HTTPException(404, "Service not found")
        await request.app.state.pool.execute(
            """INSERT INTO cookie_core_audit_logs(
                 actor_user_id,subject_user_id,service_id,action,details
               ) VALUES($1,$1,$2,'service.update','{}'::jsonb)""",
            admin.id,
            service_id,
        )
        request.app.state.proxy.clear_hostname_cache()
        return {"id": str(row["id"]), "name": row["name"]}

    @app.post(
        "/v1/admin/services/{service_id}/users/{subject_user_id}/cookies/import",
        status_code=201,
    )
    async def import_user_cookies(
        service_id: UUID,
        subject_user_id: UUID,
        data: CookieImport,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        request.app.state.rate_limiter.check("import", admin.id, 10)
        try:
            count = await request.app.state.core.import_cookies(
                actor_user_id=admin.id,
                subject_user_id=str(subject_user_id),
                service_id=str(service_id),
                raw_cookies=data.cookies,
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        return {
            "cookie_count": count,
            "status": "ready",
        }

    @app.get("/v1/admin/services/{service_id}/users/{subject_user_id}/cookies")
    async def list_user_cookies(
        service_id: UUID,
        subject_user_id: UUID,
        request: Request,
        _: AuthenticatedUser = Depends(current_admin),
    ):
        row = await request.app.state.pool.fetchrow(
            """SELECT count(c.id) AS cookie_count,
                      count(c.id) FILTER (
                        WHERE c.revoked_at IS NULL
                          AND (c.expires_at IS NULL OR c.expires_at > now())
                      ) AS active_count,
                      array_remove(array_agg(DISTINCT c.name),NULL) AS cookie_names,
                      array_remove(array_agg(DISTINCT c.domain),NULL) AS domains,
                      max(c.expires_at) AS latest_expiry
               FROM cookie_core_stored_cookies c
               WHERE c.user_id=$1 AND c.service_id=$2""",
            str(subject_user_id),
            service_id,
        )
        return {
            "cookie_count": row["cookie_count"],
            "cookie_names": row["cookie_names"],
            "domains": row["domains"],
            "latest_expiry": row["latest_expiry"],
            "status": "ready" if row["active_count"] else "not_configured",
        }

    @app.delete(
        "/v1/admin/services/{service_id}/users/{subject_user_id}/cookies",
        status_code=204,
    )
    async def delete_user_cookies(
        service_id: UUID,
        subject_user_id: UUID,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        async with request.app.state.pool.acquire() as conn, conn.transaction():
            deleted = await conn.fetchval(
                """DELETE FROM cookie_core_stored_cookies
                   WHERE user_id=$1 AND service_id=$2 RETURNING id""",
                str(subject_user_id),
                service_id,
            )
            if not deleted:
                raise HTTPException(404, "Cookies are not configured")
            await conn.execute(
                """INSERT INTO cookie_core_audit_logs(
                     actor_user_id,subject_user_id,service_id,action,details
                   ) VALUES($1,$2,$3,'cookies.revoke','{}'::jsonb)""",
                admin.id,
                str(subject_user_id),
                service_id,
            )
        return Response(status_code=204)

    @app.post(
        "/v1/admin/services/{service_id}/users/{subject_user_id}/localstorage/import",
        status_code=201,
    )
    async def import_user_localstorage(
        service_id: UUID,
        subject_user_id: UUID,
        data: LocalStorageImport,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        request.app.state.rate_limiter.check("import", admin.id, 10)
        try:
            count = await request.app.state.core.import_local_storage(
                actor_user_id=admin.id,
                subject_user_id=str(subject_user_id),
                service_id=str(service_id),
                raw_items=data.items,
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        return {
            "item_count": count,
            "status": "ready",
        }

    @app.get("/v1/admin/services/{service_id}/users/{subject_user_id}/localstorage")
    async def list_user_localstorage(
        service_id: UUID,
        subject_user_id: UUID,
        request: Request,
        _admin: AuthenticatedUser = Depends(current_admin),
    ):
        rows = await request.app.state.pool.fetch(
            """SELECT l.item_key, l.created_at, l.updated_at
               FROM cookie_core_stored_localstorage l
               WHERE l.user_id=$1 AND l.service_id=$2 AND l.revoked_at IS NULL
               ORDER BY l.item_key""",
            str(subject_user_id),
            service_id,
        )
        row_count = await request.app.state.pool.fetchval(
            """SELECT count(*) FROM cookie_core_stored_localstorage
               WHERE user_id=$1 AND service_id=$2 AND revoked_at IS NULL""",
            str(subject_user_id),
            service_id,
        )
        return {
            "item_count": row_count,
            "keys": [
                {
                    "key": row["item_key"],
                    "created_at": row["created_at"],
                    "updated_at": row["updated_at"],
                }
                for row in rows
            ],
            "status": "ready" if row_count else "not_configured",
        }

    @app.delete(
        "/v1/admin/services/{service_id}/users/{subject_user_id}/localstorage",
        status_code=204,
    )
    async def delete_user_localstorage(
        service_id: UUID,
        subject_user_id: UUID,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        async with request.app.state.pool.acquire() as conn, conn.transaction():
            deleted = await conn.fetchval(
                """DELETE FROM cookie_core_stored_localstorage
                   WHERE user_id=$1 AND service_id=$2 RETURNING id""",
                str(subject_user_id),
                service_id,
            )
            if not deleted:
                raise HTTPException(404, "LocalStorage is not configured")
            await conn.execute(
                """INSERT INTO cookie_core_audit_logs(
                     actor_user_id,subject_user_id,service_id,action,details
                   ) VALUES($1,$2,$3,'localstorage.revoke','{}'::jsonb)""",
                admin.id,
                str(subject_user_id),
                service_id,
            )
        return Response(status_code=204)

    @app.get("/v1/admin/cf/clearance")
    async def admin_list_clearance(
        request: Request,
        _: AuthenticatedUser = Depends(current_admin),
    ):
        cache = request.app.state.browser_client.clearance
        entries = []
        import time as _t

        now = _t.time()
        for domain, rec in list(cache._data.items()):
            entries.append(
                {
                    "domain": domain,
                    "expires_in": max(0, int(rec.expires_at - now)),
                    "expires_at": int(rec.expires_at),
                }
            )
        entries.sort(key=lambda e: e["domain"])
        return {
            "count": len(entries),
            "provider": str(request.app.state.settings.cf_solver_provider.value),
            "providers": [
                provider.value for provider in request.app.state.settings.solver_provider_list
            ],
            "entries": entries,
        }

    @app.post("/v1/admin/cf/clearance", status_code=201)
    async def admin_inject_clearance(
        data: CfClearanceInject,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        request.app.state.rate_limiter.check("admin-write", admin.id, 30)
        cache = request.app.state.browser_client.clearance
        cache.set(data.domain, data.cf_clearance, ttl=data.ttl_seconds)
        logger.info(
            "Admin %s injected cf_clearance domain=%s ttl=%ss",
            admin.id,
            data.domain,
            data.ttl_seconds,
        )
        return {
            "domain": data.domain,
            "ttl_seconds": data.ttl_seconds,
            "status": "cached",
        }

    @app.delete("/v1/admin/cf/clearance/{domain}", status_code=204)
    async def admin_clear_clearance(
        domain: str,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        cache = request.app.state.browser_client.clearance
        if domain == "__all__":
            cache.clear(None)
            request.app.state.browser_client.cloudflare_sessions.clear(None)
            logger.info("Admin %s cleared entire cf_clearance cache", admin.id)
        else:
            cache.clear(domain)
            request.app.state.browser_client.cloudflare_sessions.clear(
                domain,
                egress_identity=request.app.state.browser_client._egress_identity,
            )
            logger.info("Admin %s cleared cf_clearance domain=%s", admin.id, domain)
        return Response(status_code=204)

    @app.get("/v1/admin/cf/status")
    async def admin_cf_status(
        request: Request,
        _: AuthenticatedUser = Depends(current_admin),
    ):
        s = request.app.state.settings
        from .config import CfSolverProvider

        return {
            "provider": str(s.cf_solver_provider.value),
            "providers": [provider.value for provider in s.solver_provider_list],
            "configured": bool(s.solver_provider_list)
            and bool(
                s.cf_solver_api_key
                or s.cf_solver_api_keys
                or CfSolverProvider.CUSTOM in s.solver_provider_list
            ),
            "timeout_seconds": s.cf_solver_timeout_seconds,
            "max_retries": s.cf_solver_max_retries,
            "impersonate_targets": list(s.cf_solver_impersonate_targets),
            "current_impersonate": request.app.state.browser_client.impersonate,
            "endpoint": str(s.cf_solver_api_endpoint) if s.cf_solver_api_endpoint else None,
            "cookie_provider": {
                "configured": s.cloudflare_cookie_provider_enabled,
                "auto_refresh": s.cf_auto_refresh,
                "cached_sessions": len(request.app.state.browser_client.cloudflare_sessions),
                "inflight_solves": (
                    request.app.state.browser_client._cookie_coordinator.inflight_count
                    if request.app.state.browser_client._cookie_coordinator
                    else 0
                ),
                "circuit_state": (
                    getattr(
                        request.app.state.browser_client._cookie_coordinator.provider,
                        "circuit_state",
                        "closed",
                    )
                    if request.app.state.browser_client._cookie_coordinator
                    else "disabled"
                ),
                "egress_id": request.app.state.browser_client._egress_identity,
            },
        }

    @app.post("/v1/admin/cf/solve")
    async def admin_solve_url(
        data: CfSolveUrlInput,
        request: Request,
        admin: AuthenticatedUser = Depends(current_admin),
    ):
        """Fetch a URL through the proxy transport, detect a Cloudflare
        challenge, run the configured third-party solver, and cache the
        resulting ``cf_clearance`` so future proxy requests inherit it.

        Useful both as a diagnostic tool (``GET /v1/admin/cf/status`` to see
        the resulting entry) and as a way to pre-warm the cache for a
        hostname that is currently 429/403 before the real user navigates to
        it.
        """
        from .browser_client import (
            _looks_like_cloudflare_challenge,
            _looks_like_cloudflare_response,
            _parse_retry_after,
        )

        request.app.state.rate_limiter.check("cf-solve", admin.id, 2)
        client: BrowserLikeClient = request.app.state.browser_client
        url = str(data.url)
        try:
            await request.app.state.egress_guard.check(url)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        if data.impersonate not in request.app.state.settings.cf_solver_impersonate_targets:
            raise HTTPException(400, "Unsupported browser impersonation target")
        # Do not mutate/close the shared transport while real users are making
        # requests. Rotation is coordinated inside BrowserLikeClient when a
        # genuine challenge is observed.
        headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "accept-language": "en-US,en;q=0.9",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        }
        probe_request = client.build_request("GET", url, headers=headers)
        probe_request.extensions["cookie_core_timeout"] = float(data.max_timeout_seconds)
        try:
            probe, _probe_headers, _probe_domain = await client._send_once(
                probe_request, stream=False, materialized_body=b""
            )
        except Exception as exc:
            logger.warning(
                "cf_probe_failed request_id=%s error=%s",
                getattr(request.state, "request_id", "unknown"),
                type(exc).__name__,
            )
            raise HTTPException(502, "Upstream probe failed") from exc

        status = probe.status_code
        body = probe.content or b""
        is_challenge = _looks_like_cloudflare_challenge(status, body, probe.headers)
        is_cf_response = _looks_like_cloudflare_response(status, probe.headers)
        retry_after = _parse_retry_after(probe.headers)
        result_summary: dict[str, Any] = {
            "url": url,
            "status_code": status,
            "cf_challenge_detected": is_challenge,
            "cf_response_headers_present": is_cf_response,
            "retry_after_seconds": retry_after,
            "response_bytes": len(body),
            "solver": None,
            "cookie_provider": None,
            "cached_clearance": None,
        }
        if status == 429:
            result_summary["note"] = (
                "Upstream is rate limited. Retry-After must be respected; "
                "clearance solving was not attempted."
            )
            return result_summary
        if not (is_challenge or is_cf_response):
            result_summary["note"] = (
                "Probe did not detect a Cloudflare challenge or CF-branded "
                "4xx/5xx response. The origin may be healthy for this IP, or "
                "its protection is implemented purely in the app layer."
            )
            return result_summary

        coordinator = client._cookie_coordinator
        if coordinator is not None and is_challenge:
            observed_generation = client.cloudflare_sessions.generation(
                url, egress_identity=client._egress_identity
            )
            try:
                session = await coordinator.refresh(
                    url,
                    observed_generation=observed_generation,
                )
            except Exception as exc:
                result_summary["cookie_provider"] = {
                    "ran": True,
                    "success": False,
                    "error": type(exc).__name__,
                }
            else:
                domain = (urlparse(url).hostname or "").lower()
                clearance_cookie = next(
                    (cookie for cookie in session.cookies if cookie.name == "cf_clearance"),
                    None,
                )
                if clearance_cookie is not None and domain:
                    client.clearance.set(
                        domain,
                        clearance_cookie.value,
                        ttl=max(1, int(session.expires_at - time.time())),
                    )
                result_summary["cookie_provider"] = {
                    "ran": True,
                    "success": True,
                    "cookie_count": len(session.cookies),
                    "cf_clearance_obtained": clearance_cookie is not None,
                    "expires_at": int(session.expires_at),
                }
                result_summary["cached_clearance"] = {
                    "domain": domain,
                    "present": clearance_cookie is not None,
                }
                return result_summary

        solver = await client._get_solver()
        if solver is None:
            result_summary["solver"] = {
                "ran": False,
                "reason": "no solver provider configured",
            }
            return result_summary

        try:
            solve_result = await solver.try_solve(url, status, body, probe.headers)
        except Exception as exc:
            result_summary["solver"] = {"ran": True, "success": False, "error": str(exc)}
            return result_summary

        result_summary["solver"] = {
            "ran": True,
            "provider": solve_result.provider.value,
            "success": solve_result.success,
            "cf_clearance_obtained": bool(solve_result.cf_clearance),
            "clearance_ttl_seconds": solve_result.clearance_ttl,
            "turnstile_token_obtained": bool(solve_result.turnstile_token),
            "error": solve_result.error,
        }
        domain = (urlparse(url).hostname or "").lower()
        if domain:
            existing = client.clearance.get(domain)
            result_summary["cached_clearance"] = {"domain": domain, "present": bool(existing)}
        return result_summary

    @app.api_route(
        "/proxy/{service_id}",
        methods=["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        include_in_schema=False,
    )
    async def canonical_proxy_root(service_id: UUID, request: Request):
        """Add the slash required by the grant cookie's scoped Path.

        Rewritten absolute-origin navigations can legitimately produce
        ``/proxy/<service-id>``. Without this canonical redirect FastAPI falls
        through to the transparent catch-all and the browser also withholds the
        ``Path=/proxy/<service-id>/`` session cookie.
        """
        query = request.scope.get("query_string", b"").decode("latin-1")
        raw_path = request.scope.get("raw_path", request.url.path.encode("latin-1"))
        path_value = raw_path.decode("latin-1") if isinstance(raw_path, bytes) else request.url.path
        destination = path_value + "/" + ("?" + query if query else "")
        return RedirectResponse(destination, status_code=307)

    @app.api_route(
        "/proxy/{service_id}/{path:path}",
        methods=["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    )
    async def proxy_http(service_id: UUID, path: str, request: Request):
        request.state.cookie_core_proxy = True
        return await request.app.state.proxy.http(str(service_id), path, request)

    @app.websocket("/proxy/{service_id}/{path:path}")
    async def proxy_websocket(websocket: WebSocket, service_id: UUID, path: str):
        await websocket.scope["app"].state.proxy.websocket(websocket, str(service_id), path)

    @app.api_route(
        "/{path:path}",
        methods=["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        include_in_schema=False,
    )
    async def transparent_proxy_http(path: str, request: Request):
        service_id, hostname = await _transparent_service(
            request.app.state.proxy,
            request.headers,
            request.url.hostname,
        )
        if not service_id:
            raise HTTPException(
                404,
                "Not found",
                headers={"X-Cookie-Core-Error-Source": "proxy-core:hostname"},
            )
        request.state.cookie_core_proxy = True
        return await request.app.state.proxy.http(
            service_id,
            path,
            request,
            transparent=True,
            transparent_hostname=hostname,
        )

    @app.websocket("/{path:path}")
    async def transparent_proxy_websocket(websocket: WebSocket, path: str):
        proxy = websocket.scope["app"].state.proxy
        service_id, hostname = await _transparent_service(
            proxy,
            websocket.headers,
            websocket.url.hostname,
        )
        if not service_id:
            await websocket.close(code=4404)
            return
        await websocket.scope["app"].state.proxy.websocket(
            websocket,
            service_id,
            path,
            transparent=True,
            transparent_hostname=hostname,
        )

    return app


app = create_app()
